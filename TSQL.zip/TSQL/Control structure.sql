
-- declaration
declare @name varchar(20)
declare @age int

-- initialization
set @name = 'pramod'
set @age = 22


-- print ( puts in messages tab)
--print @name
--print @age

-- select * from emp

select @name 
select @age



if @name = 'pramod'
begin
	print 'name is present'
end



if @age > 18
begin 
	print 'age is greater than 18'
end
else
begin 
	print 'age is not greater than 18'
end


if @name = 'pramod'
begin
	print 'pramod is present' 
end
else if @name = 'john'
begin
	print 'john is present'
end
else
begin
	print 'name is invalid'
end
	

declare @num int
set @num = 0

while @num <= 100
begin
	if ( (@num %2) = 0)
	begin
		print @num
	end
	set @num = @num+1
end



select LOC =
	case LOC
	when  'NEW YORK' then  'bangalore'
	when  'chicago' then  'mumbai'
	when  'dallas' then  'delhi'
	when  'boston' then  'kolkata'
	end
from DEPT


select 
	case
	when  LOC = 'NEW YORK' then  'bangalore'
	when  LOC = 'dallas' then   'mumbai'
	when  LOC = 'chicago' then   'delhi'
	when  LOC = 'boston' then   'kolkata'
	end
from DEPT



SELECT * FROM EMP
