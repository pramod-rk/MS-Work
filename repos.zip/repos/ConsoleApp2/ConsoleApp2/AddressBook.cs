﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class AddressBook
    {
        List<Address> address = new List<Address>();

        public void addAddress(string emailID, string firstName, string lastName, 
            string streetAddress, string city, string state, string country, int postalCode)
        {
            if(address.Find( i => i.FirstName == firstName))
            address.Add(new Address(emailID, firstName, lastName, streetAddress, city, state, country, postalCode));         
            
        }
    }
}
