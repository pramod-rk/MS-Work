﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Address
    {
         string? EmailID { get; set; }
         string? FirstName { get; set; }
         string? LastName { get; set; }  
         string? StreetAddress { get; set; }
         string? City { get; set; }  
         string? State { get; set; }
         string? Country{get; set;}  
         int PostalCode { get; set; }
        private int phnNo;



        
        
        public Address(string? emailID, string? firstName, string? lastName, string? streetAddress, string? city, string? state, string? country, int postalCode)
        {
            EmailID = emailID;
            FirstName = firstName;
            LastName = lastName;
            StreetAddress = streetAddress;
            City = city;
            State = state;
            Country = country;
            PostalCode = postalCode;
        }
    }
}
