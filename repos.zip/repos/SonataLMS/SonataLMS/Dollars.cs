﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public  class Dollars
    {
        private double money;

        public Dollars(double money)
        {
            try {
                Money = money;
            }
            catch (Exception e){
                Console.WriteLine(e.Message);
            
            }
            
            
        }

        public double Money
        {
            get
            {
                return (money * 79.08);
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("negative value not allowed");
                }
                else
                {
                    money = value;
                    
                }
            }
        }
    }

    
}
