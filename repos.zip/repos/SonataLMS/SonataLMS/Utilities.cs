﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    static class Utilities
    {

        //public static void Main(string[] args)
        //{
        //    string s = "hello world";
        //    string a = s.StringToTitleCase();
        //    Console.WriteLine(a);

        //}


        //static string StringToTitleCase(this string a)
        //{
        //    string[] str = a.Split(" ");
        //    string s = "";

        //    for (int i = 0; i < str.Length ; i++)
        //    {
        //        str[i] = str[i][0].ToString().ToUpper() + str[i].Substring(1, str[i].Length - 1);
        //    }
        //    foreach (string str2 in str)
        //    {
        //        s = s + " " + str2;

        //    }
        //    return s;

        //}
    }
}
