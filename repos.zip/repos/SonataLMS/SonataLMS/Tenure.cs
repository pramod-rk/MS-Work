﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public class Tenure
    {
        public DateTime DateOfJoining ;
        //public DateTime currentDate = DateTime.Now;

        public Tenure(DateTime date)
        {
            this.DateOfJoining = date;
        }


        public double TenureDays()
        {
            try
            {
               // DateTime dt = DateTime.Parse(DateOfJoining);

                double ts = DateTime.Today.Year - this.DateOfJoining.Year;
                return ts;
            }
            catch
            {
                return 0;
            }
         
            
            
        }
       


    }
}
