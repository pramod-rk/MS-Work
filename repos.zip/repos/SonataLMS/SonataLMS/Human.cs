﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public class Human
    {

        protected string? firstName;
        protected string? lastName;

        public Human(string? firstName, string? lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public string? FirstName
        {
            get { return this.firstName; }
            set { this.firstName = value; } 
        }
        public string? LastName
        {
            get { return this.lastName; }
            set { this.lastName = value; }
        }
    }


    public class Student : Human
    {
        private double mark;

        public Student( string firstName, string lastName, double mark ):base(firstName, lastName)
        {
            this.mark = mark;
            
        }

    }


    public class Worker : Human
    {
        private double wage;
        private double hoursWorked;
        public Worker( string? firstName, string? lastName,  double wage, double hoursWorked):base(firstName, lastName)
        {
            this.wage = wage;
            this.hoursWorked = hoursWorked;
        }
    }
}
