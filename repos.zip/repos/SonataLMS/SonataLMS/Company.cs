﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public class Company : CompanyManager
    {
        public string? Name { get; set; }
        public string? address { get; set; }
        public int phoneNumber { get; set; }
        public int faxNumber { get; set; }
        public string? website { get; set; }

        public Company(string? name, string? address, int phoneNumber, int faxNumber, 
            string? website, string? managerName, string? surname, int managerPhoneNumber) 
            : base(managerName, surname, managerPhoneNumber)
        {
            Name = name;
            this.address = address;
            this.phoneNumber = phoneNumber;
            this.faxNumber = faxNumber;
            this.website = website;
        }

        
    }


    public class CompanyManager 
    {
        public string? name { get; set; }
        public string? surname { get; set; }
        public int phoneNumber { get; set; }


        public CompanyManager( string? name, string? surname, int phoneNumber)
        {
            this.name = name;
            this.surname = surname;
            this.phoneNumber = phoneNumber;
        }
    }
}
