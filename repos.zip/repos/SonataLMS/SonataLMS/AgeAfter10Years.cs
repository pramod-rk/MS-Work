﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public class AgeAfter10Years
    {
        public int AgeInFuture(int age)
        {
            return (age + 10);
        }
    }
}
