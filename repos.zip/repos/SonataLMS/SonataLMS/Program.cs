﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    internal class Program
    {
        public static void Main(string[] args)
        {

            //Console.WriteLine("enter DOJ");
            //DateTime d =DateTime.Parse( Console.ReadLine());
            //Tenure t1 = new Tenure(d);
            //Console.WriteLine(t1.TenureDays());

            //Person p1 = new Person("pramod", new DateTime(2000,02,22), "123 xyz road", "single");
            //Console.WriteLine(p1.GetAge());
            // Console.WriteLine(p1.CanMarry());
            // Console.WriteLine(p1.PrintDetails());

            //FourDigitNumber fourDigitNumber = new FourDigitNumber();
            //int a = 1234;
            //fourDigitNumber.ActionOnFourDigits(a);

            int[] arr = new int[] {1,2,3,4};
            Subset subsets = new Subset();
            var x =  subsets.Subsets(arr);
            foreach (var i in x)
            {
                var temp = string.Join<int>(",", i);
                temp = "{" + temp + "}";
                Console.WriteLine(temp);
            }
        }



    }
}
