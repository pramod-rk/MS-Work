﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public class FourDigitNumber
    {
        public void ActionOnFourDigits(int a)
        {
            if (a >= 1000 && a <= 9999)
            {
                Console.WriteLine("The sum of digits is " + SumOfDigit(a));
                Console.WriteLine("The reversed number is " + ReversedNumber(a));
                Console.WriteLine("The swapped number is " + MiddleSwap(a));
                Console.WriteLine("The last digit in the first position number " + LastToFirst(a));


            }
            else
            {
                Console.WriteLine("Enter four digit number");
            }
        }


        public int SumOfDigit(int a)
        {
            int result = 0;
            while(a != 0)
            {
                int b = a % 10;
                result = result + a;
                a = a / 10;
            }
            return result;
        }

        public int ReversedNumber(int a)
        {
            int revNum = 0;
            while(a != 0)
            {
                revNum = (revNum * 10) + (a % 10);
                a = a / 10;
            }
            return revNum;
        }


        public int MiddleSwap(int a)
        {
            string s = "";
            string b = a.ToString();
            char[] arr = b.ToCharArray();
            char x = arr[1];
            arr[1] = arr[2];
            arr[2] = x;
            foreach(char c in arr)
            {
                s = s + c;
            }
            return int.Parse(s);

        }

        public int LastToFirst(int a)
        {
            string s = "";
            string b = a.ToString();
            char[] arr = b.ToCharArray();
            char x = arr[0];
            arr[0] = arr[3];
            arr[3] = x;
            foreach (char c in arr)
            {
                s = s + c;
            }
            return int.Parse(s);
        }

    }
}
