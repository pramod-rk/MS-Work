﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public  class Circle
    {
        private double radius;


        // Circle Set Radius
        public void SetRadius(double radius)
        {
            this.radius = radius;
        }


        // Circle Get Radius
        public double GetRadius()
        {
            return this.radius;
        }


        // Circle Diameter
        public double CalcDiameter()
        {
            return (2 * radius);
        }


        // Circle Area
        public double CalcArea()
        {
            return (radius * radius * Math.PI);
        }
        
    }
}
