﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public class Person
    {
        private string name;
        private DateTime doB;
        private string address;
        private string maritalStatus;


        // Constructor
        public Person(string name, DateTime doB, string address, string maritalStatus)
        {
            Name = name;
            DoB = doB;
            Address = address;
            MaritalStatus = maritalStatus;
        }


        // Properties
        public string Name
        {
            set { name = value; }
            get { return name; }
        }

        public DateTime DoB
        {
            set { doB = value; }
            get { return doB; }
        }

        public string Address
        {
            set { address = value; }
            get
            {
                return address;
            }
        }

        public string MaritalStatus
        {
            set
            {
                string[] a = new string[] {
                    "single",
                    "married",
                    "divorced",
                    "widowed"};
                foreach(string i in a)
                {
                    if(i.Equals( value))
                    {
                        maritalStatus = value;  
                    }

                }
            }
            get { return maritalStatus; }
        }


        // Get Age
        public int GetAge()
        {
            int age = DateTime.Today.Year - DoB.Year;
            return age;
        }


        // Can Marry
        public bool CanMarry()
        {
            if(MaritalStatus.Equals("married")  || GetAge() < 18)
                {
                    return false;
                }
         
            return true;
        }


        // Print Details
        public string PrintDetails()
        {
             string CanMarryString()
            {
                if (CanMarry())
                {
                    return "can marry";
                }
                else
                {
                    return "cannot marry";
                }

            }

            return ($"{Name} lives at {Address}, born on {DoB.ToShortDateString()}, {MaritalStatus}, {GetAge()} years old and {CanMarryString()}");
        }







    }
}
