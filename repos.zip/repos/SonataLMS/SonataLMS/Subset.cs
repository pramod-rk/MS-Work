﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonataLMS
{
    public class Subset
    {
        public void SumZeroSubset()
        {

        }

        public HashSet<HashSet<int>> Subsets(int[] list)
        {
            
            // Init list
            HashSet<HashSet<int>> subsets = new HashSet<HashSet<int>>();

            subsets.Add(new HashSet<int>()); // add the empty set

            // Loop over individual elements
            for (int i = 1; i < list.Length; i++)
            {
                subsets.Add(new HashSet<int>() { list[i - 1] });

                HashSet<HashSet<int>> newSubsets = new HashSet<HashSet<int>>();

                // Loop over existing subsets
                for (int j = 0; j < subsets.Count; j++)
                {
                    var newSubset = new HashSet<int>();
                    foreach (var temp in subsets[j])
                        newSubset.Add(temp);

                    newSubset.Add(list[i]);


                    newSubsets.Add(newSubset);
                }

                subsets.AddRange(newSubsets);
            }

            // Add in the last element
            subsets.Add(new HashSet<int>() { list[list.Length - 1] });

            return subsets;
        }

    }
}
